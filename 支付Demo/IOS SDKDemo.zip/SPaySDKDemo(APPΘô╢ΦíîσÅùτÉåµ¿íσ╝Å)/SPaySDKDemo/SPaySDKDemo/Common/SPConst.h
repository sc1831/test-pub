//
//  SPConst.h
//  SPaySDKDemo
//
//  Created by wongfish on 15/6/14.
//  Copyright (c) 2015年 wongfish. All rights reserved.
//

#import <Foundation/Foundation.h>


/**
 *   商户密钥值
 */
FOUNDATION_EXPORT NSString *const kSPconstSPaySignVal;


/**
 *  6.1.3	预下单接口地址
 */
FOUNDATION_EXPORT NSString *const kSPconstWebApiInterface_spay_pay_gateway;



/**
 *  接口基础地址
 */
FOUNDATION_EXPORT NSString *const kSPayBaseUrl;