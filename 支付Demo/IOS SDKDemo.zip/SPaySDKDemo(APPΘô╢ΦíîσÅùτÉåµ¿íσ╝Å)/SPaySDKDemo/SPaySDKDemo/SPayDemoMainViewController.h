//
//  SPayDemoMainViewController.h
//  SPaySDKDemo
//
//  Created by wongfish on 15/6/11.
//  Copyright (c) 2015年 wongfish. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SPayDemoMainViewController : UITableViewController

@end
