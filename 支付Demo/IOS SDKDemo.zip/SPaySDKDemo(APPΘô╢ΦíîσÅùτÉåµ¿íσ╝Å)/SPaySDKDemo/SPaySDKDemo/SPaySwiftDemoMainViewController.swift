//
//  SPaySwiftDemoMainViewController.swift
//  SPaySDKDemo
//
//  Created by qiuqiu on 16/3/16.
//  Copyright © 2016年 wongfish. All rights reserved.
//

import Foundation
import UIKit



class SPaySwiftDemoMainViewController:UIViewController{
    
    var spayTokenIDString : NSString = ""
    var amount :NSNumber = 0.0
    var payServicesString :NSString = ""
    
    
    
    override func viewDidLoad(){
        
        super.viewDidLoad()
        
        
        SPayClient.sharedInstance().pay(self, amount: amount, spayTokenIDString: spayTokenIDString as String, payServicesString: "pay.weixin.app" as String) { (payStateModel, paySuccessDetailModel) -> Void in
            
            if(payStateModel.payState == SPayClientConstEnumPaySuccess){
                NSLog("%@", "支付成功");
            }else{
                
                NSLog("%@", "支付失败");
            }
            
        };
        
        
        
    }
    
}