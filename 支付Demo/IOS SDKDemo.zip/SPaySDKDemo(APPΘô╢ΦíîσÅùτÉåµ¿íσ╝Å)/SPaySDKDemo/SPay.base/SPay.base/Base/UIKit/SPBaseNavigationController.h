//
//  SPBaseNavigationController.h
//  SPay.base
//
//  Created by wongfish on 15/5/7.
//  Copyright (c) 2015年 wongfish. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SPBaseNavigationController : UINavigationController

@end
