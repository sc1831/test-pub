//
//  ViewController.h
//  威富通统Pay
//
//  Created by guohui on 16/3/30.
//  Copyright © 2016年 guohui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

