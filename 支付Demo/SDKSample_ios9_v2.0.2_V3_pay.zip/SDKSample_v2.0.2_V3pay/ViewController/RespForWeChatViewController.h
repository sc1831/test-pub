//
//  RespForWeChatViewController.h
//  SDKSample
//
//  Created by Tencent on 12-4-9.
//  Copyright (c) 2012年 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RespForWeChatViewController : UIViewController

@end
